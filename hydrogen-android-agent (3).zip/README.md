# Hydrogen Android Agent (`gemini-4-hydrogen`)

Минималистичный Android-агент управления смартфоном на базе **Gemini 4 Hydrogen** (`Interactions API` + `Function Calling`) с авто-повтором и резервными моделями при нагрузке (HTTP 503).

## Как собрать APK за 2 минуты
1. Загрузите файлы из этого архива (или сам архив + `.github/workflows/build-apk.yml`) в репозиторий на GitHub.
2. Откройте вкладку **Actions** — сборка запустится автоматически.
3. Скачайте артефакт **`hydrogen-agent-debug-apk`** (`app-debug.apk`) и установите на телефон.
4. Нажмите **API Key** и вставьте свой `GEMINI_API_KEY`.

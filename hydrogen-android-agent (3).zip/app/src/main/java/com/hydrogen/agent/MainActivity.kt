package com.hydrogen.agent

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity() {

    private lateinit var tvChat: TextView
    private lateinit var tvModelBadge: TextView
    private lateinit var scrollChat: ScrollView
    private lateinit var etPrompt: EditText
    private lateinit var btnSend: Button
    private lateinit var btnApiKey: Button
    private lateinit var cbAutoApprove: CheckBox

    private lateinit var tools: SystemTools
    private val gemini = GeminiClient()
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var previousInteractionId: String? = null

    private val availableModels = arrayOf(
        "gemini-4-hydrogen",
        "gemini-3.8-flash",
        "gemini-3.5-flash-lite"
    )
    private var selectedModel = "gemini-4-hydrogen"

    private val confirmRequired = setOf(
        "toggle_flashlight",
        "set_volume",
        "open_app_or_settings",
        "open_url",
        "send_notification",
        "vibrate"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tools = SystemTools(this)
        tvChat = findViewById(R.id.tvChat)
        tvModelBadge = findViewById(R.id.tvModelBadge)
        scrollChat = findViewById(R.id.scrollChat)
        etPrompt = findViewById(R.id.etPrompt)
        btnSend = findViewById(R.id.btnSend)
        btnApiKey = findViewById(R.id.btnApiKey)
        cbAutoApprove = findViewById(R.id.cbAutoApprove)

        requestNotificationPermissionIfNeeded()

        tvModelBadge.setOnClickListener { showModelPicker() }
        btnApiKey.setOnClickListener { showApiKeyDialog() }
        btnSend.setOnClickListener { sendMessage() }

        appendLine("Hydrogen Agent готов. Модель: $selectedModel (нажмите на название модели сверху для смены; при HTTP 503 резервная модель включится автоматически).")
        if (getSavedApiKey().isBlank()) {
            appendLine("⚠️ Нажмите 'API Key' и вставьте ваш Gemini API ключ.")
        }
    }

    private fun showModelPicker() {
        val currentIdx = availableModels.indexOf(selectedModel).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Выберите модель")
            .setSingleChoiceItems(availableModels, currentIdx) { dialog, which ->
                selectedModel = availableModels[which]
                tvModelBadge.text = "$selectedModel ▾"
                previousInteractionId = null
                appendLine("🔄 Модель переключена на $selectedModel")
                dialog.dismiss()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun getSavedApiKey(): String {
        val prefs = getSharedPreferences("hydrogen_prefs", MODE_PRIVATE)
        return prefs.getString("gemini_api_key", "") ?: ""
    }

    private fun saveApiKey(key: String) {
        getSharedPreferences("hydrogen_prefs", MODE_PRIVATE)
            .edit()
            .putString("gemini_api_key", key.trim())
            .apply()
    }

    private fun showApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "AIza..."
            setText(getSavedApiKey())
        }
        AlertDialog.Builder(this)
            .setTitle("Gemini API Key")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                saveApiKey(input.text.toString())
                appendLine("✅ API ключ сохранён.")
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun appendLine(text: String) {
        tvChat.append(text + "\n\n")
        scrollChat.post { scrollChat.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendMessage() {
        val prompt = etPrompt.text.toString().trim()
        if (prompt.isEmpty()) return

        val apiKey = getSavedApiKey()
        if (apiKey.isBlank()) {
            showApiKeyDialog()
            return
        }

        etPrompt.setText("")
        btnSend.isEnabled = false
        appendLine("Вы: $prompt")

        scope.launch {
            try {
                runAgentLoop(apiKey, prompt)
            } catch (e: Exception) {
                appendLine("❌ Ошибка: ${e.message}")
            } finally {
                btnSend.isEnabled = true
            }
        }
    }

    private suspend fun runAgentLoop(apiKey: String, userPrompt: String) {
        val preamble = "Ты — Hydrogen, локальный ИИ-агент управления Android-смартфоном (${Build.MODEL}, Android ${Build.VERSION.RELEASE}). " +
            "Используй доступные инструменты для выполнения системных задач. Отвечай кратко и на русском языке.\n\n" +
            "Запрос пользователя: $userPrompt"

        val inputPayload: Any = if (previousInteractionId == null) preamble else userPrompt

        var response = withContext(Dispatchers.IO) {
            gemini.createInteractionWithFallback(
                apiKey = apiKey,
                preferredModel = selectedModel,
                fallbackModels = availableModels.filter { it != selectedModel },
                input = inputPayload,
                fallbackFreshInput = preamble,
                tools = tools.toolDeclarations(),
                previousInteractionId = previousInteractionId
            )
        }
        if (response.usedModel != selectedModel) {
            appendLine("ℹ️ $selectedModel перегружен (503), использована резервная модель: ${response.usedModel}")
        }
        previousInteractionId = response.id
        var activeModel = response.usedModel

        var rounds = 0
        while (response.functionCalls.isNotEmpty() && rounds < 10) {
            val results = JSONArray()
            for (call in response.functionCalls) {
                val allowed = if (call.name in confirmRequired && !cbAutoApprove.isChecked) {
                    askUserConfirmation(call.name, call.arguments)
                } else {
                    true
                }

                val resultObj = if (allowed) {
                    appendLine("⚡ ${call.name}(${call.arguments})")
                    withContext(Dispatchers.IO) {
                        tools.execute(call.name, call.arguments)
                    }
                } else {
                    appendLine("⛔ Отклонено пользователем: ${call.name}")
                    JSONObject().put("status", "cancelled_by_user")
                }

                results.put(
                    JSONObject().apply {
                        put("type", "function_result")
                        put("name", call.name)
                        put("call_id", call.id)
                        put(
                            "result",
                            JSONArray().put(
                                JSONObject().apply {
                                    put("type", "text")
                                    put("text", resultObj.toString())
                                }
                            )
                        )
                    }
                )
            }

            response = withContext(Dispatchers.IO) {
                gemini.createInteractionWithFallback(
                    apiKey = apiKey,
                    preferredModel = activeModel,
                    fallbackModels = availableModels.filter { it != activeModel },
                    input = results,
                    fallbackFreshInput = results,
                    tools = tools.toolDeclarations(),
                    previousInteractionId = previousInteractionId
                )
            }
            previousInteractionId = response.id
            activeModel = response.usedModel
            rounds++
        }

        val replyText = response.outputText.ifBlank { "(пустой ответ)" }
        appendLine("Hydrogen: $replyText")
    }

    private suspend fun askUserConfirmation(name: String, args: JSONObject): Boolean =
        suspendCancellableCoroutine { cont ->
            AlertDialog.Builder(this)
                .setTitle("Разрешить действие?")
                .setMessage("Инструмент: $name\nПараметры: $args")
                .setPositiveButton("Разрешить") { _, _ ->
                    if (cont.isActive) cont.resume(true)
                }
                .setNegativeButton("Отмена") { _, _ ->
                    if (cont.isActive) cont.resume(false)
                }
                .setOnCancelListener {
                    if (cont.isActive) cont.resume(false)
                }
                .show()
        }
}

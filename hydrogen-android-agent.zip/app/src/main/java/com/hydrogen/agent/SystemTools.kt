package com.hydrogen.agent

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

class SystemTools(private val context: Context) {

    fun toolDeclarations(): JSONArray = JSONArray().apply {
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "get_device_info",
              "description": "Получить статус батареи, модель телефона, версию Android и свободную память.",
              "parameters": {"type": "object", "properties": {}}
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "toggle_flashlight",
              "description": "Включить или выключить фонарик на телефоне.",
              "parameters": {
                "type": "object",
                "properties": {
                  "enabled": {"type": "boolean", "description": "true — включить, false — выключить."}
                },
                "required": ["enabled"]
              }
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "set_volume",
              "description": "Установить уровень громкости (в процентах 0-100) для media, ring или alarm.",
              "parameters": {
                "type": "object",
                "properties": {
                  "stream": {"type": "string", "enum": ["media", "ring", "alarm"]},
                  "percent": {"type": "integer", "description": "Громкость от 0 до 100."}
                },
                "required": ["stream", "percent"]
              }
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "open_app_or_settings",
              "description": "Открыть системные настройки (wifi, bluetooth, settings, camera, alarm) или приложение по package name.",
              "parameters": {
                "type": "object",
                "properties": {
                  "target": {"type": "string", "description": "wifi, bluetooth, settings, camera, alarm или package name (например com.whatsapp)."}
                },
                "required": ["target"]
              }
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "open_url",
              "description": "Открыть веб-ссылку в браузере.",
              "parameters": {
                "type": "object",
                "properties": {
                  "url": {"type": "string", "description": "URL с http:// или https://"}
                },
                "required": ["url"]
              }
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "send_notification",
              "description": "Показать локальное уведомление на телефоне.",
              "parameters": {
                "type": "object",
                "properties": {
                  "title": {"type": "string"},
                  "message": {"type": "string"}
                },
                "required": ["title", "message"]
              }
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "copy_to_clipboard",
              "description": "Скопировать текст в буфер обмена телефона.",
              "parameters": {
                "type": "object",
                "properties": {
                  "text": {"type": "string"}
                },
                "required": ["text"]
              }
            }
            """.trimIndent())
        )
        put(
            JSONObject("""
            {
              "type": "function",
              "name": "vibrate",
              "description": "Включить вибрацию на заданное число миллисекунд.",
              "parameters": {
                "type": "object",
                "properties": {
                  "duration_ms": {"type": "integer", "description": "Длительность в мс (например 300)."}
                },
                "required": ["duration_ms"]
              }
            }
            """.trimIndent())
        )
    }

    fun execute(name: String, args: JSONObject): JSONObject {
        return try {
            when (name) {
                "get_device_info" -> getDeviceInfo()
                "toggle_flashlight" -> toggleFlashlight(args.optBoolean("enabled", false))
                "set_volume" -> setVolume(args.optString("stream", "media"), args.optInt("percent", 50))
                "open_app_or_settings" -> openAppOrSettings(args.optString("target", "settings"))
                "open_url" -> openUrl(args.optString("url", ""))
                "send_notification" -> sendNotification(
                    args.optString("title", "Hydrogen"),
                    args.optString("message", "")
                )
                "copy_to_clipboard" -> copyToClipboard(args.optString("text", ""))
                "vibrate" -> vibrate(args.optInt("duration_ms", 250))
                else -> JSONObject().put("error", "Неизвестный инструмент: $name")
            }
        } catch (e: Exception) {
            JSONObject().put("error", e.message ?: "Ошибка выполнения")
        }
    }

    private fun getDeviceInfo(): JSONObject {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryPct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val isCharging = bm.isCharging

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeGb = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
        val totalGb = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)

        return JSONObject().apply {
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("android_version", Build.VERSION.RELEASE)
            put("battery_percent", batteryPct)
            put("is_charging", isCharging)
            put("storage_free_gb", String.format("%.2f", freeGb))
            put("storage_total_gb", String.format("%.2f", totalGb))
        }
    }

    private fun toggleFlashlight(enabled: Boolean): JSONObject {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = cm.cameraIdList.firstOrNull()
            ?: return JSONObject().put("error", "Камера со вспышкой не найдена")
        cm.setTorchMode(cameraId, enabled)
        return JSONObject().put("status", "ok").put("flashlight", enabled)
    }

    private fun setVolume(stream: String, percent: Int): JSONObject {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val streamType = when (stream) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
        val clamped = percent.coerceIn(0, 100)
        val max = am.getStreamMaxVolume(streamType)
        val target = (max * clamped / 100.0).toInt().coerceIn(0, max)
        am.setStreamVolume(streamType, target, AudioManager.FLAG_SHOW_UI)
        return JSONObject().put("status", "ok").put("stream", stream).put("percent", clamped)
    }

    private fun openAppOrSettings(target: String): JSONObject {
        val intent = when (target.lowercase()) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "settings" -> Intent(Settings.ACTION_SETTINGS)
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "alarm" -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            else -> context.packageManager.getLaunchIntentForPackage(target)
                ?: return JSONObject().put("error", "Приложение '$target' не найдено")
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return JSONObject().put("status", "ok").put("opened", target)
    }

    private fun openUrl(url: String): JSONObject {
        val safeUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(safeUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return JSONObject().put("status", "ok").put("url", safeUrl)
    }

    private fun sendNotification(title: String, message: String): JSONObject {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "hydrogen_agent_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "Hydrogen Agent", NotificationManager.IMPORTANCE_DEFAULT)
            nm.createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 10000).toInt(), notif)
        return JSONObject().put("status", "ok")
    }

    private fun copyToClipboard(text: String): JSONObject {
        val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("Hydrogen", text))
        return JSONObject().put("status", "ok").put("length", text.length)
    }

    private fun vibrate(durationMs: Int): JSONObject {
        val ms = durationMs.coerceIn(50, 3000).toLong()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        }
        return JSONObject().put("status", "ok").put("duration_ms", ms)
    }
}

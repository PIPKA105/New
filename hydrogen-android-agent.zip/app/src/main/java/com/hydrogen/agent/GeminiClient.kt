package com.hydrogen.agent

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class FunctionCallStep(
    val id: String,
    val name: String,
    val arguments: JSONObject
)

data class InteractionResponse(
    val id: String,
    val outputText: String,
    val functionCalls: List<FunctionCallStep>
)

class GeminiClient {

    private val endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"
    private val modelId = "gemini-4-hydrogen"

    fun createInteraction(
        apiKey: String,
        input: Any,
        tools: JSONArray,
        previousInteractionId: String? = null
    ): InteractionResponse {
        val body = JSONObject().apply {
            put("model", modelId)
            put("input", input)
            put("tools", tools)
            if (!previousInteractionId.isNullOrBlank()) {
                put("previous_interaction_id", previousInteractionId)
            }
        }

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(body.toString())
        }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }

        if (code !in 200..299) {
            throw RuntimeException("HTTP $code: $raw")
        }

        val json = JSONObject(raw)
        val interactionId = json.optString("id", "")
        val calls = mutableListOf<FunctionCallStep>()
        val textParts = mutableListOf<String>()

        val directOutput = json.optString("output_text", "")
        if (directOutput.isNotBlank()) {
            textParts.add(directOutput)
        }

        val steps = json.optJSONArray("steps") ?: JSONArray()
        for (i in 0 until steps.length()) {
            val step = steps.optJSONObject(i) ?: continue
            when (step.optString("type")) {
                "function_call" -> {
                    calls.add(
                        FunctionCallStep(
                            id = step.optString("id"),
                            name = step.optString("name"),
                            arguments = step.optJSONObject("arguments") ?: JSONObject()
                        )
                    )
                }
                else -> {
                    if (directOutput.isBlank()) {
                        val content = step.optJSONArray("content")
                        if (content != null) {
                            for (j in 0 until content.length()) {
                                val part = content.optJSONObject(j) ?: continue
                                val txt = part.optString("text", "")
                                if (txt.isNotBlank()) textParts.add(txt)
                            }
                        }
                    }
                }
            }
        }

        return InteractionResponse(
            id = interactionId,
            outputText = textParts.joinToString("\n").trim(),
            functionCalls = calls
        )
    }
}

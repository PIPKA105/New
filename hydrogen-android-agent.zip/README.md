# Hydrogen Android Agent (`gemini-4-hydrogen`)

Минималистичный Android-агент управления смартфоном на базе **Gemini 4 Hydrogen** (`Interactions API` + `Function Calling`) со сборкой APK прямо на GitHub Actions.

## Как собрать APK за 2 минуты
1. Создайте новый репозиторий на GitHub и загрузите все файлы из этого архива (включая скрытую папку `.github/workflows/build-apk.yml`).
2. Откройте вкладку **Actions** в репозитории — сборка запустится автоматически (или нажмите **Run workflow**).
3. После завершения откройте последний запуск и скачайте артефакт **`hydrogen-agent-debug-apk`** (`app-debug.apk`).
4. Установите APK на Android-телефон и введите свой `GEMINI_API_KEY` по кнопке **API Key** в правом верхнем углу.

## Что умеет агент
- `get_device_info` — заряд батареи, модель, версия Android, свободная память.
- `toggle_flashlight` — включение и выключение фонарика.
- `set_volume` — управление громкостью (мультимедиа, звонок, будильник).
- `open_app_or_settings` — открытие настроек (Wi-Fi, Bluetooth, общие, камера, будильник) или приложений по package name.
- `open_url` — открытие ссылок в браузере.
- `send_notification` — отправка локального уведомления.
- `copy_to_clipboard` — копирование текста в буфер обмена.
- `vibrate` — виброотклик.
